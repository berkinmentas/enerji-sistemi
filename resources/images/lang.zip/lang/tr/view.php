<?php
return [
    'header.contact.button' => 'BİZE ULAŞ',
    'header.menu.button' => 'MENÜ',

    'header.menu.modal.home' => 'ANASAYFA',
    'header.menu.modal.institutional' => 'KURUMSAL',
    'header.menu.modal.investor' => 'YATIRIMCI İLİŞKİLERİ',
    'header.menu.modal.members' => 'ÜYELER',
    'header.menu.modal.projects' => 'PROJELER',
    'header.menu.modal.press' => 'BASIN ODASI',
    'header.menu.modal.contact' => 'İLETİŞİM',

    'contact.form.name' => 'Ad Soyad',
    'contact.form.email' => 'Mail',
    'contact.form.phone' => 'Telefon',
    'contact.form.message' => 'Mesaj',
    'contact.form.message.send' => 'Mesaj gönder',
    'contact.form.message.text' => 'Mesajınız kaydedildi.',
    'contact.form.message.title' => 'Mesaj',

    'footer.description' => "FCR gayrimenkul, Fecri Koça tarafından İstanbul'da kurulan inşaat sektöründe tasarım, proje geliştirme ve uygulama şirketidir.",
    'footer.links' => "LİNKLER",

    'read.more.button' => "DEVAMINI OKU",

    'stat.streams.title' => "GAYRİMENKUL ve İLGİLİ SEKTÖRLERDEKİ YENİLİKLERİ TAKİP EDEREK DÜNYA STANDARTLARINDA PROJELER
                    GERÇEKLEŞTİRİP MARKA DEĞERİ YÜKSEK ALANLAR YARATIR.",
    'stat.stream.item1.description' => "Uzun yıllardır sektördeki ulusal ve uluslararası projelerde güvenin adresiyiz.",
    'stat.stream.item1.title' => "Tek İşimiz Bu",
    'stat.stream.item2.description' => "Bu gün sahip olduğumuz tecrübe, hız ve esnekliğe katkı sağlayan, büyüdüğümüz bir yıl oldu",
    'stat.stream.item2.title' => "Doğru Adımlar.",
    'stat.stream.item3.description' => "Öngörülebilir bir büyüme ile gayrimenkul portföy ve piyasa değerini arttırmayı ve
                                    bunu yaparken hissedarlarına dürüst olmayı, onların hak ve hukuklarını korumayı temel
                                    felsefesi haline getirmiştir.",
    'stat.stream.item3.title' => "FCR Gayrimenkul Yatırım Ortaklığı.",

    'learn.more.button' => "DAHA FAZLA BİLGİ EDİN",

    'stats.title' => "RAKAMLARLA FCR Gayrimenkul",
    'stats.description' => "FCR Gayrimenkul tecrübeyle doğru projelerle öncü, güçlü, saygın ve dünya standartlarında bir şirket olma hedefine emin adımlarla ilerlemektedir.",
    'stats.item1' => "ÜLKEDE FAALİYET",
    'stats.item2' => "YILI AŞKIN TECRÜBE",
    'stats.item3' => "ULUSRARASI PROJE",

    'project.title' => "PROJELER",
    'project.description' => "Sektöründe uzun yılları aşan tecrübeyle doğru projelerle öncü, güçlü, saygın ve dünya
                            standartlarında bir şirket olma Hedefine emin adımlarla ilerlemektedir. Etik ve güvenilir
                            olma ilkesi ile hareket eden FCR Gayrimenkul, kazanmayı ve kazandırmayı amaç edinmiştir.",
    'see.all.button' => 'TÜMÜNÜ GÖR',

    'schedule.visit.title' => "BİZİ ZİYARET ET",
    'schedule.visit.description' => " FCR Gayrimenkul Yatırım Ortaklığı hakkında daha fazla bilgi almak ve bizimle tanışmak için sizi
                        ofisimizde misafir etmek isteriz.",

    'schedule.visit.text1' => "Pazartesi - Cuma",
    'schedule.visit.text2' => "Cumartesi",
    'schedule.visit.text3' => "Pazar",
    'schedule.visit.text3.value' => "Kapalı",

    'comment.primary.box.title' => "FCR GAYRİMENKUL HAKKINDA",

    'subscriptions.title' => "BİLGİLERİNİZİ BIRAKIN, SİZİ ARAYALIM",
    'subscriptions.form.name' => 'Ad Soyad',
    'subscriptions.form.email' => 'Mail',
    'subscriptions.form.phone' => 'Telefon',
    'subscriptions.form.message.send' => 'MESAJ GÖNDER',
    'subscriptions.form.message.text' => 'Mesajınız kaydedildi. En kısa sürede geri dönüş yapılacaktır.',
    'subscriptions.form.message.title' => 'Bilgi',

    'contact.page.title' => 'SORULARINIZI BİZE GÖNDERİN',

    'project.land.area.text' => 'Arsa alanı',
    'project.construction.zone.text' => 'İnşaat alanı',

    'member.not.found' => 'Üye bulunamadı',

];
